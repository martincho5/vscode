
These scripts require the free Active Directory cmdlets from Dell/Quest:

    http://www.quest.com/powershell/



